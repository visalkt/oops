package Packages.package1;

public class B {
    private static String privatemsg = "This is a private message from B";
    public static void main(String[] args) {
        System.out.println(privatemsg);
    }
}
