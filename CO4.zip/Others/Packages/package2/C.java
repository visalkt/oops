package Packages.package2;

public class C {
    
    public static String defaultmsg = "This is a default message from C";
    protected static String protectedmsg = "This is a protected message from C";
}
