package Arithmetic;

public interface Operations {

    double operate();
    
}

