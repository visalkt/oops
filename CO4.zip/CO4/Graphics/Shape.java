package Graphics;

public interface Shape {

    double area();
    
} 
